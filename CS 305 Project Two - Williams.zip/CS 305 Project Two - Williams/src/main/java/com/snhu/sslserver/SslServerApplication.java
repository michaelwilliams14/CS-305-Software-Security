package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

@RestController
class ServerController {

	// Converts byte array digest to hexadecimal string
	public static String bytesToHex(byte[] bytes) {
		StringBuilder hexString = new StringBuilder();
		for (byte b : bytes) {
			String hex = Integer.toHexString(0xff & b);
			if (hex.length() == 1) {
				hexString.append('0');
			}
			hexString.append(hex);
		}
		return hexString.toString();
	}

	@GetMapping("/hash")
	public String myHash() {
		// Unique data string containing your name and client name
		String data = "Hello World Checksum - Michael Williams - Artemis Financial";
		String checksum = "";

		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			byte[] hashBytes = md.digest(data.getBytes(StandardCharsets.UTF_8));
			checksum = bytesToHex(hashBytes);
		} catch (NoSuchAlgorithmException e) {
			return "<p>Error calculating cryptographic hash: " + e.getMessage() + "</p>";
		}

		return "<p>data: " + data + "</p>" +
		       "<p>Name of Cipher Algorithm Used: SHA-256</p>" +
		       "<p>SHA-256 Checksum Value: " + checksum + "</p>";
	}
}