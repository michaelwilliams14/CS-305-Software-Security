package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class ServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServerApplication.class, args);
    }
}

@RestController
class ServerController {

    // Helper method to convert byte array to a full 64-character hex string
    public static String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

    public static String calculateHash(String data, String algorithm) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance(algorithm);
        byte[] hashBytes = md.digest(data.getBytes(StandardCharsets.UTF_8));
        return bytesToHex(hashBytes);
    }

    @RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException {
        // Unique string containing your first and last name as required by rubric
        String data = "Hello World Checksum Check! - Michael Williams";
        String cipherAlgorithm = "SHA-256";
        String hash = calculateHash(data, cipherAlgorithm);

        return "<p>Data: " + data + "</p>" +
               "<p>Algorithm: " + cipherAlgorithm + "</p>" +
               "<p>Checksum Value: " + hash + "</p>";
    }
}